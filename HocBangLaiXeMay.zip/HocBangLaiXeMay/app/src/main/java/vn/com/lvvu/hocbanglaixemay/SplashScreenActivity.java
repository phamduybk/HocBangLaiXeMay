package vn.com.lvvu.hocbanglaixemay;

import android.content.Intent;
import android.os.Handler;

import vn.com.lvvu.hocbanglaixemay.base.BaseActivity;

/**
 * Created by levan on 7/27/2019.
 */

public class SplashScreenActivity extends BaseActivity {


    @Override
    public int getLayoutID() {
        return R.layout.activity_splash_screen;
    }

    @Override
    public void initView() {
        try {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(SplashScreenActivity.this, MainActivity.class);
                        startActivity(intent);
                    } catch (Exception e) {
                        Common.handleException(e);
                    }
                }
            }, 1000);
        } catch (Exception e) {
            Common.handleException(e);
        }
    }

    @Override
    public void initData() {

    }
}
